# මගේ ලොරිය — Android APK project

මෙය HTML prototype එක Android WebView app එකක් ලෙස ඇසුරුම් කරන Android Studio/Gradle project එකකි.

## GitHub repository
ඔබේ GitHub username එක `ruwancbk` නිසා යෝජිත repository:
`https://github.com/ruwancbk/mage-lori-apk`

## GitHub Actions APK build
Workflow file:
`.github/workflows/android-apk.yml`

`main` branch එකට push කරන විට හෝ Actions tab එකෙන් `Build Mage Lori APK` workflow එක manually run කරන විට APK එක build වේ. APK එක `mage-lori-debug-apk` නමින් workflow artifact එකක් ලෙස ලබාගත හැක.

## APK download steps
1. GitHub repository එක විවෘත කරන්න.
2. **Actions** tab එක තෝරන්න.
3. සාර්ථකව අවසන් වූ **Build Mage Lori APK** run එක තෝරන්න.
4. පහළ ඇති **Artifacts** කොටසේ `mage-lori-debug-apk` download කරන්න.
5. ZIP එක extract කර `app-debug.apk` Android දුරකථනයට යවන්න.
6. APK එක install කරන්න. Android එකෙන් අවසර ඉල්ලුවොත් ඔබ තෝරාගත් browser/file manager එකට install unknown apps අවසරය දෙන්න.

## GitHub මත project එක upload කරන ආකාරය
1. `https://github.com/new` විවෘත කරන්න.
2. Repository name: `mage-lori-apk`
3. Public හෝ Private තෝරන්න. README, .gitignore, license GitHub වෙතින් මුලින්ම generate නොකරන්න (මෙම ZIP එකේ ඒවා/අදාළ files තිබේ).
4. Repository එක create කරන්න.
5. මේ ZIP එක extract කර සියලු files/folders repository එකට upload කරන්න. `.github` folder එකත් ඇතුළත් විය යුතුය.
6. GitHub web upload එකෙන් folders/files upload කිරීම අපහසු නම් computer එකක Git භාවිතා කරන්න:
   ```bash
   git init
   git add .
   git commit -m "Initial Mage Lori Android app"
   git branch -M main
   git remote add origin https://github.com/ruwancbk/mage-lori-apk.git
   git push -u origin main
   ```
   GitHub password වෙනුවට browser sign-in හෝ Personal Access Token අවශ්‍ය විය හැක.

## Important notes
- මෙය **debug APK** එකකි; දැනට Google Play Store සඳහා signed release build එකක් නොවේ.
- App data browser/WebView local storage තුළ සුරැකේ. App data clear කිරීම හෝ uninstall කිරීම දත්ත නැති කළ හැක; app එකේ Backup පහසුකම භාවිතා කරන්න.
- දත්ත cloud එකකට sync නොවේ.
- Android build එක GitHub Actions මත පරීක්ෂා කර build කළ පසුව APK එක භාවිතා කරන්න.
